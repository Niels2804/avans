namespace SmartEnergy.Library.Measurements.Models;

public enum Sensor
{
    energy_consumed,
    energy_produced,
    gas_delivered,
    power
}

